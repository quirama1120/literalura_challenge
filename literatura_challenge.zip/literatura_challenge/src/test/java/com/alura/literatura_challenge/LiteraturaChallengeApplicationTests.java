package com.alura.literatura_challenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiteraturaChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
